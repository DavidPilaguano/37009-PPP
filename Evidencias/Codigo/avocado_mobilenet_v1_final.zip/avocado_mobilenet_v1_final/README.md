# avocado_mobilenet_v1

Versión procesada creada desde imágenes originales de NZDLPlantDisease-v1.
Las fuentes originales no se modificaron. Las variantes aumentadas de la fuente se excluyeron para evitar fuga de datos.

Semilla de partición: `20261016`.
Imágenes internas: 27.
Imágenes de prueba externa: 186.
Rechazadas: 3.

## Distribución interna

| Split | Clase | Imágenes |
| --- | --- | ---: |
| test | algal_leaf_spot | 1 |
| test | healthy_leaf | 3 |
| train | algal_leaf_spot | 4 |
| train | healthy_leaf | 15 |
| val | algal_leaf_spot | 1 |
| val | healthy_leaf | 3 |

La prueba externa no participa en el entrenamiento, ajuste de hiperparámetros ni selección del modelo.
